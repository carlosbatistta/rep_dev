# Wons

An admin dashboard, built with flutter.

## Build
```flutter build web --web-renderer html --release```

or

```flutter build web --web-renderer canvaskit --release```


## [Demo](https://obkmdashboard.web.app)


## 📸 Banner

<p align="center">
<img src="art/banner.png" alt="banner.png" hspace="2"/>
</p>

<br />

## 🤓 Design Credit

**MALIK ALI**
(https://maliksali.com)

<br />

## 🌟❤️ Icon Credit
[svgrepo](https://www.svgrepo.com/svg/184140/android)

[maskable](https://maskable.app/editor)

[imageconvert](https://imageconvert.org/png-to-png24)
