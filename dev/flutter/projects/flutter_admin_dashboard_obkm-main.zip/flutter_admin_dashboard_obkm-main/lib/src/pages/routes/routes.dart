class PageRoutes {
  static const root = "/";

  static const login = "/login/";

  static const signup = "/signup/";

  static const recover = "/recover/";

  static const confirm = "/confirm/";
}
