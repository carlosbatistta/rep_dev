// ignore_for_file: constant_identifier_names

class Assets {
  // static const PG18_TWITTER = "assets/svg/18/twitter.svg";
}
