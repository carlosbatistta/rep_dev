class FontFamily {
  FontFamily._();

  static const String dmSans = "DMSans";
}
